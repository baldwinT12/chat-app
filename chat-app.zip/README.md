# Chat-app
A cool chat app I made! Tell me what you guys think! There are instructions in the app, enter nothing as the channel to go to the welcome channel. 
# MOVED DOMAINS
Sorry for any confusion, the new domain is https://vnmpd.csb.app That's so I can keep up with only one version at a time, limiting vulnerabilities.